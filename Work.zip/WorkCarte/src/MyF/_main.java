package MyF;

public class _main {

    public static void main(String [] args) {
    	System.out.println(Function.RandomInt(100, 1));
    }

}
