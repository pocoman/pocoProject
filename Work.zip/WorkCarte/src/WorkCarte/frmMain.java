package WorkCarte;

import java.awt.GridLayout;

import javax.swing.JFrame;

public class frmMain extends JFrame implements infWork {
	frmMain() {
		setLayout(new GridLayout(1, 1));
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		add(new pnlMain());
		pack();
	}
}

