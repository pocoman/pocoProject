package WorkCarte;

import java.awt.Dimension;

public interface infWork {
	int FRAME_WIDTH = 800;
	int FRAME_HEIGHT = 600;
	Dimension FRAME_SIZE = new Dimension(FRAME_WIDTH, FRAME_HEIGHT);
}
