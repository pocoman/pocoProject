package WorkCarte;

import javax.swing.JTabbedPane;

public class pnlTabbed extends JTabbedPane implements infWork {

	pnlWorkAdd AddPanel = new pnlWorkAdd();
	pnlWorkView ViewPanel = new pnlWorkView();
	
	public pnlTabbed() {
		addTab("View", ViewPanel);
		addTab("Add", AddPanel);
	}
}
