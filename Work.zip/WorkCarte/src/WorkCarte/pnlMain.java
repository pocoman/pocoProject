package WorkCarte;

import java.awt.BorderLayout;
import java.sql.Connection;

import javax.swing.JPanel;

import MyF.DB_MySQL;

public class pnlMain extends JPanel implements infWork {
	static Connection con;
	static {
		con = DB_MySQL.getMyConnection("localhost", "carte", "Check1234@");
		DB_MySQL.useDB(con, "workcarte");
		
	}

	pnlTabbed WorkPanel = new pnlTabbed();
	public pnlMain() {
		setPreferredSize(FRAME_SIZE);
		setLayout(new BorderLayout());
		
		add(WorkPanel, BorderLayout.CENTER);
	}
}
