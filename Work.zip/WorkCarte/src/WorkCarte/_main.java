package WorkCarte;

public class _main {

	public static void main(String[] args) {
		new frmMain();
	}

}
