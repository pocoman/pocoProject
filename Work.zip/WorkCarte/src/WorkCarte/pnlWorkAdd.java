package WorkCarte;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class pnlWorkAdd extends JPanel implements infWork {
	JTextField txfTicket = new JTextField();
	JTextField txfTitle = new JTextField();
	JTextField txfStartDate = new JTextField();
	JTextField txfEndDate = new JTextField();
	JTextField txfHour = new JTextField();
	JTextPane txpCarte = new JTextPane();
	JTextPane txpMemo = new JTextPane();
	
	JButton btSave = new JButton("Save");
	
	public pnlWorkAdd() {
		JPanel pl1 = new JPanel();
		JPanel pl1_1 = new JPanel();
		JPanel pl1_2 = new JPanel();
		
		JPanel pl2 = new JPanel();
		
		setLayout(new BorderLayout());
		pl1.setLayout(new GridLayout(2, 1));
		pl2.setLayout(new FlowLayout());
		pl1.add(pl1_1); pl1.add(pl1_2);
		
		pl1_1.setLayout(new GridLayout(5, 2));
		pl1_2.setLayout(new GridLayout(2, 2));
		
		pl1_1.add(new JLabel("Ticket Number"));		pl1_1.add(txfTicket);
		pl1_1.add(new JLabel("Title"));				pl1_1.add(txfTitle);
		pl1_1.add(new JLabel("Start Date"));		pl1_1.add(txfStartDate);
		pl1_1.add(new JLabel("End Date"));			pl1_1.add(txfEndDate);
		pl1_1.add(new JLabel("Work Hour"));			pl1_1.add(txfHour);
		
		pl1_2.add(new JLabel("Work Carte"));		pl1_2.add(txpCarte);
		pl1_2.add(new JLabel("Memo"));				pl1_2.add(txpMemo);
		
		pl2.add(btSave);
		pl2.setPreferredSize(new Dimension(this.getWidth(), 50));
		
		add(pl1, BorderLayout.CENTER);
		add(pl2, BorderLayout.SOUTH);
	}
}
