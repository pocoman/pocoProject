package WorkCarte;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.border.BevelBorder;

public class pnlWorkView extends JPanel implements infWork {
	JLabel lblTicket = new JLabel();
	JLabel lblTitle = new JLabel();
	JLabel lblStartDate = new JLabel();
	JLabel lblEndDate = new JLabel();
	JLabel lblHour = new JLabel();
	JTextPane txpCarte = new JTextPane();
	JTextPane txpMemo = new JTextPane();
	
	JButton btSave = new JButton("Save");
	
	public pnlWorkView() {
		txpCarte.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		txpCarte.setEnabled(false);
		txpMemo.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		txpMemo.setEnabled(false);
		
		JPanel pl1 = new JPanel();
		JPanel pl1_1 = new JPanel();
		JPanel pl1_2 = new JPanel();
		
		JPanel pl2 = new JPanel();
		
		setLayout(new BorderLayout());
		pl1.setLayout(new GridLayout(2, 1));
		pl2.setLayout(new FlowLayout());
		pl1.add(pl1_1); pl1.add(pl1_2);
		
		pl1_1.setLayout(new GridLayout(5, 2));
		pl1_2.setLayout(new GridLayout(2, 2));
		
		pl1_1.add(new lblWork("Ticket Number"));		pl1_1.add(lblTicket);
		pl1_1.add(new lblWork("Title"));				pl1_1.add(lblTitle);
		pl1_1.add(new lblWork("Start Date"));			pl1_1.add(lblStartDate);
		pl1_1.add(new lblWork("End Date"));				pl1_1.add(lblEndDate);
		pl1_1.add(new lblWork("Work Hour"));			pl1_1.add(lblHour);
		
		pl1_2.add(new lblWork("Work Carte"));			pl1_2.add(txpCarte);
		pl1_2.add(new lblWork("Memo"));					pl1_2.add(txpMemo);
		
		pl2.add(btSave);
		pl2.setPreferredSize(new Dimension(this.getWidth(), 50));
		
		add(pl1, BorderLayout.CENTER);
		add(pl2, BorderLayout.SOUTH);
	}
}
