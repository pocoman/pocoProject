package WorkCarte;

import javax.swing.JLabel;

public class lblWork extends JLabel {
	
	lblWork(String value) {
		super(value);
		setHorizontalAlignment(CENTER);
		setVerticalAlignment(CENTER);
	}
}
